% CONTROL FUNCTIONALS, by C.J.Oates, M.Girolami and N.Chopin
%
% SUMMARY:
% Consider the problem of computing an expectation mu = \int f(x) p(x) dx.
% The Monte Carlo solution is to simulate x from p(x) and evaluate
% mean(f(x)). Control functionals provide a Bayesian alternative to the 
% mu = mean(f) command, that uses knowledge on both the function f(x) and 
% the measure p(x) in order to deliver improved convergence rates.
%
% EXAMPLE:
% x = randn(20,1); % 20 samples from a standard Gaussian
% f = @(x) x.^2; % integrand of interest
% mu_MC = mean(f(x)); % classical Monte Carlo estimate
% u = @(x) -x; % score function (d/dx) log p(x)
% alpha = [0.1 , 1]; % hyper-parameters
% mu_CF = mean_CF(x,f,u,alpha); % control functional estimate
% The true answer here is of course mu = 1.
%
% INPUTS:
% x = nxd matrix, each row a sample from p(x)
% f = handle to target function f(x), OR a nx1 vector of function values
% u = handle to a score function u(x), OR a nxd matrix of score values
% alpha = [alpha1,alpha2] are kernel hyperparameters, described in the paper
% 
% OPTIONAL:
% mean_CF(x,f,u,alpha,'simplified') will use the simplified estimator.
%
% OUTPUTS:
% mu = control functional estimate
% var = posterior variance of the control functional estimate
% mse = predictive mean square error (for use in cross validation)
%
% � Chris. J. Oates 2015

function [mu,var,mse] = mean_CF(x,f,u,alpha,varargin)

% load data
[n,d] = size(x);
if nargin == 4
    m = ceil(0.7*n); % number of training samples
else
    m = n; % the "simplified" estimator
end
ix0 = randsample(n,m); % sample splitting
ix1 = setdiff(1:n,ix0);
x0 = x(ix0,:);
x1 = x(ix1,:);

% caveats
if n > 200
    disp('Please note that this light-weight implementation will slow down for n > 200.')
end

% base kernel and its derivatives
R = @(x,alpha) (1 + alpha(1)*sum(x.^2))^(-1);
k0 = @(x1,x2,alpha) R(x1,alpha) * R(x2,alpha) * exp(-sum((x1-x2).^2)/(2*alpha(2)^2));
dx1k0 = @(x1,x2,alpha) (-2*alpha(1)*R(x1,alpha)*x1 - (1/alpha(2))^2*(x1-x2))' * k0(x1,x2,alpha);
dx2k0 = @(x1,x2,alpha) (-2*alpha(1)*R(x2,alpha)*x2 + (1/alpha(2))^2*(x1-x2)) * k0(x1,x2,alpha);
dx1dx2k0 = @(x1,x2,alpha) (4*alpha(1)^2*x1'*x2*R(x1,alpha)*R(x2,alpha) + 2*alpha(1)*(1/alpha(2))^2*(x1-x2)'*x2*R(x2,alpha) ...
                       + (1/alpha(2))^2*eye(d) - 2*alpha(1)*(1/alpha(2))^2*x1'*(x1-x2)*R(x1,alpha) ...
                       - (1/alpha(2))^4*(x1-x2)'*(x1-x2)) * k0(x1,x2,alpha);

% load integrand
if isa(f,'function_handle') % convert f into a vector of function values
    f0 = zeros(m,1);
    for i = 1:m
        f0(i) = f(x0(i,:));
    end
    f1 = zeros(n-m,1);
    for i = 1:n-m
        f1(i) = f(x1(i,:));
    end
else 
    f0 = f(ix0);
    f1 = f(ix1);
end

% load scores
if isa(u,'function_handle') % convert u into a matrix of scores
    u0 = zeros(m,d);
    for i = 1:m
        u0(i,:) = u(x0(i,:));
    end
    u1 = zeros(n-m,d);
    for i = 1:n-m
        u1(i,:) = u(x1(i,:));
    end
else
    u0 = u(ix0,:);
    u1 = u(ix1,:);
end

% Compute covariance matrices
K0 = zeros(m);
for i = 1:m
    for j = i:m
        K0(i,j) = trace(dx1dx2k0(x0(i,:),x0(j,:),alpha)) ...
                  + dx2k0(x0(i,:),x0(j,:),alpha)*(u0(i,:)') ...
                  + dx1k0(x0(i,:),x0(j,:),alpha)'*(u0(j,:)') ...
                  + u0(i,:)*(u0(j,:)')*k0(x0(i,:),x0(j,:),alpha);
        K0(j,i) = K0(i,j);
    end
end
K10 = zeros(n-m,m);
K1 = zeros(n-m);
for i = 1:n-m
    for j = 1:m
        K10(i,j) = trace(dx1dx2k0(x1(i,:),x0(j,:),alpha)) ...
                   + dx2k0(x1(i,:),x0(j,:),alpha)*(u1(i,:)') ...
                   + dx1k0(x1(i,:),x0(j,:),alpha)'*(u0(j,:)') ...
                   + u1(i,:)*(u0(j,:)')*k0(x1(i,:),x0(j,:),alpha);
    end
    for j = 1:n-m
        K1(i,j) = trace(dx1dx2k0(x1(i,:),x1(j,:),alpha)) ...
                  + dx2k0(x1(i,:),x1(j,:),alpha)*(u1(i,:)') ...
                  + dx1k0(x1(i,:),x1(j,:),alpha)'*(u1(j,:)') ...
                  + u1(i,:)*(u1(j,:)')*k0(x1(i,:),x1(j,:),alpha);
    end
end
K01 = K10';


% Regularisation
K0 = tikhonov(K0);

% Compute the estimator
f1_hat = K10*(K0\f0) + (ones(n-m,1) - K10*(K0\ones(m,1)))*(ones(1,m)*(K0\f0))/(1 + ones(1,m)*(K0\ones(m,1)));
mu = (1/(n-m)) * ones(1,n-m) * (f1 - f1_hat) ...
     + (ones(1,m) * (K0 \ f0)) / (1 + ones(1,m) * (K0 \ ones(m,1)));
 
% Posterior variance (under improper prior)
var = (1/(n-m)^2) * ( ...
      (1 - ones(1,m)*(K0\(K01*ones(n-m,1))) - ones(1,n-m)*(K10*(K0\ones(m,1))) + ones(1,n-m)*(K10*(K0\(ones(m)*(K0\(K01*ones(n-m,1))))))) / (ones(1,m)*(K0\ones(m,1))) ...
      + ones(1,n-m)*(K1*ones(n-m,1)) - ones(1,n-m)*(K10*(K0\(K01*ones(n-m,1)))));
  
% Predictive mean square error
mse = mean((f1 - f1_hat).^2);

end

function x = tikhonov(M)
% Automatically select the regularisation hyper-parameter \lambda

x = M;
d = size(x,1);
bad_condition = rcond(x) < 10^(-15); % 10^(-15) is machine precision
lambda = 10^(-10); % starting value
while bad_condition
    lambda = 10*lambda;
    x = x + lambda^2*eye(d);
    bad_condition = rcond(x) < 10^(-15);
end
disp(['lambda used = ',num2str(lambda)])

end



















