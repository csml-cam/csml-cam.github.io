% SARCOS robot arm example.
% Outputs estimates for the predictive mean, based on Monte Carlo samples
% from the parameter prior for [theta(1) theta(2)].
% Run the code several times to observe that the variation in mu_CF across 
% runs is lower compared to the variation of mu_MC across runs.

function [mu_MC,mu_CF] = example()

% Data
load('data.mat')
mu = mean(X,1);
X = bsxfun(@minus,X,mu); % subtract column mean
sigma = std(X,1);
X = bsxfun(@rdivide,X,sigma); % normalise
Xstar = bsxfun(@minus,Xstar,mu); % subtract column mean of X
Xstar = bsxfun(@rdivide,Xstar,sigma); % normalise via X
mu = mean(y);
sigma = std(y);
y = (y - mu)/sigma;
ystar = (ystar - mu)/sigma; % normalise via y

% Subsample the data
ix = randsample(size(X,1),1000);
X = X(ix,:);
y = y(ix);
N = size(X,1);
Nprime = 100; % subset of regressors approximation 
ix = randsample(N,Nprime);
Xprime = X(ix,:);
Ntest = size(Xstar,1);

% Underlying distribution
a = 25; b = 0.04; c = 25; d = 0.04; % max cov / length scale
u = @(theta) ([a-1, c-1]./theta - 1./[b, d])'; % score
n = 50; % number of Monte Carlo samples
theta = [gamrnd(a,b,n,1), gamrnd(c,d,n,1)]; % MC samples

% Target function 
f_vals = zeros(Ntest,n);
for i = 1:n
    K_star_Nprime = K_robot(Xstar,Xprime,theta(i,:));
    K_Nprime = K_robot(Xprime,Xprime,theta(i,:));
    K_Nprime_N = K_robot(Xprime,X,theta(i,:));
    K_N_Nprime = K_Nprime_N';
    sigma = 0.1;
    f_vals(:,i) = K_star_Nprime * ((K_Nprime_N * K_N_Nprime + sigma^2*K_Nprime) \ (K_Nprime_N * y));
end


% Estimation
alpha = [0.1 , 1];
mu_MC = zeros(Ntest,1); % classical Monte Carlo
mu_CF = zeros(Ntest,1); % control functionals
for i = 1:Ntest
    fi = squeeze(f_vals(i,:))';
    mu_MC(i) = mean(fi);
    cd('../')
    mu_CF(i) = mean_CF(theta,fi,u,alpha,'simplified');
    cd('SARCOS')
end

end

function K = K_robot(X1,X2,theta)
% SARCOS model covariance function
K = zeros(size(X1,1),size(X2,1));
for i = 1:size(X1,1)
    for j = 1:size(X2,1)
        K(i,j) = theta(1) * exp(-sum((X1(i,:)-X2(j,:)).^2)/(2 * theta(2)^2));
    end
end
end










