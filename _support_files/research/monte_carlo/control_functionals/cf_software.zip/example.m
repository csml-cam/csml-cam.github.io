%% Example

PI = 3.14159265358979323846264338327950288419716939937510;

n = 100; % number of samples
d = 2; % dimension of the state space
x = randn(n,d); % random samples
alpha = [0.1 , 1]; % hyper-parameters
u = @(x) -x'; % score vector (d/dx) log p(x)
f = @(x) 1 + sin(PI*sum(x,2)/d); % integrand of interest

mu = 1; % true integral
mu_MC = mean(f(x)); % classical Monte Carlo estimate
mu_CF = mean_CF(x,f,u,alpha,'simplified'); % control functional estimate

disp(['Truth = ',num2str(mu),', Monte Carlo = ',num2str(mu_MC),', Control Functionals = ',num2str(mu_CF)])