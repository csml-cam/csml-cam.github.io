% ODE normalising constant example.
% Outputs estimates for the log marginal likelihood, based on Monte Carlo 
% samples and thermodynamic integration.
% Run the code several times to observe that the variation in mu_CF across 
% runs is lower compared to the variation of mu_MC and mu_ZV across runs.

function [mu_MC,mu_ZV,mu_CF] = example()

% Generate data using MCMC
formulate_problem();
load('samples')
n = 20; % number of samples
ix = randsample(size(theta,3),n); % draw samples by subsampling MCMC output

% Thermodynamic integration
[mu_MC,mu_ZV,mu_CF] = thermodynamic_integral(ti,theta(:,:,ix),loglike(ix,:),z(:,:,ix),w(:,:,ix));       

end

function formulate_problem()

% the prior can cause really big negative values of the log likelihood, so
% need very closely spaced temperatures near the prior
ti = ((0:30)'/30).^5;

rng(1); % random seed
theta_true = 1;
time = ([0:1:10])';
sigma = 0.1;
x0 = [0,2];

% Simulation
odefun = @(s,x) [x(2); theta_true*(1-x(1)^2)*x(2) - x(1)]; % van der Pol
[~,x] = ode45(odefun,time,x0');
y = mvnrnd(x,sigma^2*eye(2)); % y is time x variables
y = y(:,1)';

% Perform MCMC
N = 510;
burn = 10;
epsilon = 1.5*ones(size(ti));
theta0 = ones(1,length(ti));
model_handle = @(theta,t) model(theta,t,y,time); % only observe the first component
[theta,loglike,z,w] = samples(N,burn,epsilon,ti,model_handle,theta0);
save('samples','theta','loglike','z','w','N','burn','epsilon','theta0','ti')

end

% Computes the thermodynamic integral
% Inputs:
% N = number of iterations
% burn = number of iterations to discard as burn-in
% epsilon = mMALA step size
% ti = temperature schedule
% model = function handle to the statistical model
% theta0 = num params x num temperatures; initial values
% Outputs:
% theta = number of parameters x number of temperatures x N
% loglike = values of the loglikelihood, N x number of temperatures
% z = linear control variates, num params x num temperatures x N
% w = quadratic control variates, num params x num temperatures x N
function [theta,loglike,z,w,pop_accept,mmala_accept] = samples(N,burn,epsilon,ti,model_handle,theta0)

% Initialise
d = size(theta0,1);
theta = zeros(d,length(ti),N);
theta(:,:,1) = theta0;
loglike = zeros(N,length(ti)); % values of log[p(y|theta)] where theta is drawn from the power posterior
z = zeros(d,length(ti),N); % values of the control variates
w = zeros(d+d+d*(d-1)/2,length(ti),N); % values of the modified control variates for the second order scheme

% Prevent redundant recalculation
global chainstats 
chainstats = cell(7,length(ti));
for i = 1:length(ti)
    [chainstats{1,i},chainstats{2,i},chainstats{3,i},chainstats{4,i},chainstats{5,i},chainstats{6,i},chainstats{7,i}] = model_handle(theta0(:,i),ti(i));
    loglike(1,i) = chainstats{1,i};
    z(:,i,1) = chainstats{2,i};
    w(:,i,1) = chainstats{3,i};   
end

% MCMC sampling
pop_accept = 0; pop_n = 0;
mmala_accept = zeros(length(ti),1); mmala_n = 0;
for n = 2:N
    freq = 5; 
    if mod(n,freq) == 1
        [theta(:,:,n),loglike(n,:),z(:,:,n),w(:,:,n),alpha] = population(theta(:,:,n-1),loglike(n-1,:),z(:,:,n-1),w(:,:,n-1),ti,model_handle); % between-chain
        if n > burn
            pop_accept = pop_accept + alpha;
            pop_n = pop_n + 1;
        end
    else
        [theta(:,:,n),loglike(n,:),z(:,:,n),w(:,:,n),alpha] = mmala(theta(:,:,n-1),epsilon,ti,model_handle); % within-chain
        if n > burn
            mmala_accept = mmala_accept + alpha;
            mmala_n = mmala_n + 1;
        end
    end
    disp(['theta = ',num2str(theta(:,:,n))])
end
pop_accept = pop_accept / pop_n;
mmala_accept = mmala_accept / mmala_n;
disp(['Acceptance rates: ',num2str(mmala_accept'),' (mMALA), ',num2str(pop_accept'),' (population)'])

% Discard burn-in
theta = theta(:,:,burn+1:end);
loglike = loglike(burn+1:end,:);
z = z(:,:,burn+1:end);
w = w(:,:,burn+1:end);

% Display
figure(73)
for j = 1:d
    for i = 1:length(ti)
        subplot(d,length(ti),(j-1)*length(ti)+i)
        vals = squeeze(theta(j,i,:));
        plot(vals)
        if i == 1
            ylabel(['theta_',num2str(j,'%u')])
        end
        if j == 6
            xlabel(['t = ',num2str(ti(i))])
        end
        ACF = autocorr(vals,2);
        ESS = (N-burn) * (1 - ACF(2)) / (1 + ACF(2));
        title(['ESS = ',num2str(ESS,'%u'),'/',num2str(N,'%u')])
    end
end

end

% van der Pol oscillator.
% Input:
% theta = model parameter
% t = inverse temperature
% y = data, variables x time points matrix
% time = sampling time points (row vector)
% Outputs:
% l = log-likelihood (only) at theta
% L = log-target density (i.e. power posterior) at theta (up to additive constant)
% U = score function at theta. i.e. \nabla_\theta log[p(y|theta)^t * p(theta)]
% G = metric tensor at theta
% IG = inverse of the metric tensor at theta
% z = control variates -0.5 grad log[target]
% w = modified control variates for second order scheme
function [l,z,w,L,U,G,IG] = model(theta,t,y,time)

[~,n] = size(y);
num_params = 1;
num_vars = 2;
x0 = [0,2]';
sigma = 0.1;
mu0 = 0; sigma0 = 0.25; % prior hyperparameters

ix = zeros(num_vars,num_params);
for i = 1:num_params
    for k = 1:num_vars
        ix(k,i) = num_vars + num_params*(k-1) + i;
    end
end

function dxdt = f(~,x_aug)
    dim = num_vars + num_params*num_vars;
    dxdt = zeros(dim,1);
    dxdt(1) = x_aug(2); 
    dxdt(2) = theta*(1-x_aug(1)^2)*x_aug(2) - x_aug(1);
    
    F1 = zeros(num_vars,num_params); % F1(k,i) = \partial f_k / \partial \theta_i
    F1(1,1) = 0;
    F1(2,1) = (1-x_aug(1)^2)*x_aug(2);
            
    F2 = zeros(num_vars,num_vars); % F2(k,i) = \partial f_k / \partial x_i
    F2(1,1) = 0;
    F2(1,2) = 1;
    F2(2,1) = -2*theta*x_aug(1)*x_aug(2) - 1;
    F2(2,2) = theta*(1-x_aug(1)^2);
   
    S = zeros(num_vars,num_params); 
    for i = 1:num_params
        for k = 1:num_vars
            S(k,i) = x_aug(ix(k,i)); % \partial x_k / \partial \theta_i
        end
    end
    for i = 1:num_params
        for k = 1:num_vars
             dxdt(ix(k,i)) = F1(k,i) + F2(k,:)*S(:,i);            
        end
    end

end
odefun = @(s,x_aug) f(s,x_aug); 
x_aug_0 = [x0; zeros(num_params*num_vars,1)];

try
    [~,x_aug] = ode15s(odefun,time,x_aug_0');
    x_aug = x_aug';

    % extract variables from x_aug
    x = x_aug(1:num_vars,:);
    S = zeros(n,num_vars,num_params); % S(j,k,i) = \partial x_k / \partial \theta_i at time s_j
    for k = 1:num_vars
        for i = 1:num_params
            S(:,k,i) = x_aug(ix(k,i),:)';
        end
    end

    % likelihood
    l = -n*log(2*pi*sigma^2) - (2*sigma^2)^(-1)*sum(sum((y(1,:)-x(1,:)).^2)); % only observe the first component
    L = t*l + sum( -log(theta) - log(sigma0) - 0.5*log(2*pi) - 0.5*sigma0^(-2)*(log(theta)-mu0)^2 ); 

    % scores
    U = zeros(num_params,1);
    for i = 1:num_params
        U(i) = -(1/theta(i)) * (1 + (log(theta(i)) - mu0)/(sigma0^2));
        for j = 1:n
            U(i) = U(i) + (t/(sigma^2))*squeeze(S(j,1,i))*(y(1,j)-x(1,j)); % only observe the first component
        end
    end
    z = -U/2;

    % tensor
    G = zeros(num_params);
    for i = 1:num_params
        for m = i:num_params
            for j = 1:n
                G(i,m) = G(i,m) + (t/(sigma^2)) * squeeze(S(j,1,i)) * squeeze(S(j,1,m))'; % only observe the first component
            end
            if i == m
                G(i,m) = G(i,m) + (1/(theta(i)^2)) * ((log(theta(i)) - mu0 + 1)/(sigma0^2) - 1);
            else
                G(m,i) = G(i,m);
            end
        end
    end
    IG = inv(G);

    v = zeros(num_params*(num_params-1)/2,1);
    for j = 1:num_params % this is copied from Theo's paper
        for i = j+1:num_params
            v((2*num_params-j)*(j-1)/2+(i-j)) = theta(i)*z(j) + theta(j)*z(i);
        end
    end
    w = [z; theta.*z - 0.5*ones(num_params,1); v];

catch err
    disp('ODE could not be solved')
    l = -inf;
    L = -inf;
    z = [];
    w = [];
    U = [];
    G = [];
    IG = [];
end


end

% Generates the next sample from a mMALA chain
% Inputs:
% theta = number of parameters x number of temperatures
% theta(:,i) = current model parameters for chain i (column vector)
% epsion = proposal step size, one for each temperature
% ti = temperature schedule
% model = function handle to the statistical model
% Outputs:
% theta_new = num params x num temperatures
% loglike_new = 1 x number of temperatures
% z_new = num params x num temperatures
% w_new = num quad params x num temperatures
% alpha = acceptance probabilities
function [theta_new,loglike_new,z_new,w_new,alpha] = mmala(theta,epsilon,ti,model_handle)

global chainstats % prevent redundant recalculation

% Parallel update
alpha = zeros(length(ti),1);
theta_new = theta;
loglike_new = zeros(1,length(ti));
d = size(theta,1);
z_new = zeros(d,length(ti));
w_new = zeros(d+d+d*(d-1)/2,length(ti));

for i = 1:length(ti)
    t = ti(i);
    l0 = chainstats{1,i};
    z0 = chainstats{2,i};
    w0 = chainstats{3,i};
    L0 = chainstats{4,i};
    U0 = chainstats{5,i};
    G0 = chainstats{6,i};
    IG0 = chainstats{7,i};
    
    % Proposal    
    thetai_star = mvnrnd((theta(:,i) + (epsilon(i)^2/2)*(IG0*U0))', epsilon(i)^2*IG0)'; % propose

    % Metropolis-Hastings step   
    q01 = mvnpdf(thetai_star', (theta(:,i) + (epsilon(i)^2/2)*(IG0*U0))', epsilon(i)^2*IG0);
    [l1,z1,w1,L1,U1,G1,IG1] = model_handle(thetai_star,t);
    
    % Make sure IG1 is a valid covariance matrix
    [~,err] = cholcov(IG1,0);
               
    if (L1 > -inf) && (err == 0) 
        q10 = mvnpdf(theta(:,i)', (thetai_star + (epsilon(i)^2/2)*(IG1*U1))', epsilon(i)^2*IG1);
        r = exp(L1-L0)*(q10/q01);
        alpha(i) = min(1,r); % acceptance probability
    else
        alpha(i) = 0;
    end
    if rand() < alpha(i)
        theta_new(:,i) = thetai_star;
        loglike_new(i) = l1;
        z_new(:,i) = z1;
        w_new(:,i) = w1;
        chainstats{1,i} = l1;
        chainstats{2,i} = z1;
        chainstats{3,i} = w1;
        chainstats{4,i} = L1;
        chainstats{5,i} = U1;
        chainstats{6,i} = G1;
        chainstats{7,i} = IG1;
    else
        loglike_new(i) = l0;
        z_new(:,i) = z0;
        w_new(:,i) = w0;
    end
end

end

% Generates the next sample using a population mcmc update
% Inputs:
% theta = number of parameters x number of temperatures
% theta(:,i) = current model parameters for chain i (column vector)
% loglike = 1 x num temparatures
% z = num params x num temperatures
% w = num quad params x num temperatures
% ti = temperature schedule
% model = function handle to the statistical model
% Outputs:
% theta_new = num params x num temperatures
% loglike_new = 1 x number of temperatures
% z_new = num params x num temperatures
% w_new = num quad params x num temperatures
% alpha = acceptance probabilities
function [theta_new,loglike_new,z_new,w_new,alpha] = population(theta,loglike,z,w,ti,model_handle)

global chainstats % prevent redundant recalculation

% Parallel update
theta_new = theta;
loglike_new = loglike;
z_new = z;
w_new = w;
ix_permute = randperm(length(ti)); % determines which pairs to consider swapping
ti_permute = ti(ix_permute);
alpha = 0; % acceptance probability (proposal is uniform)
for i = 1:length(ti_permute) % propose to swap state vector across temperatures
    % temperatures
    t0 = ti(i); t1 = ti_permute(i);
    ix0 = i; ix1 = ix_permute(i);
    % parameters
    theta_new0 = theta_new(:,ix0);
    theta_new1 = theta_new(:,ix1);
    % lower param, lower temp
    L00 = chainstats{4,ix0};
    % higher param, higher temp
    L11 = chainstats{4,ix1};
    % proposal statistics    
    [l01,z01,w01,L01,U01,G01,IG01] = model_handle(theta_new0,t1); % lower param, higher temp
    [l10,z10,w10,L10,U10,G10,IG10] = model_handle(theta_new1,t0); % higher param, lower temp
    % Make sure IG01, IG10 are valid covariance matrices
    [~,err01] = cholcov(IG01,0);
    [~,err10] = cholcov(IG10,0);
    if (err01 ~= 0) || (err10 ~= 0)
        %warning('Singular matrices encountered')
    end
    % Metropolis-Hastings step
    r = exp(L01 + L10 - L00 - L11);
    if (L00 == -inf) || (L11 == -inf)
        warning('Zeros encountered')
    end
    if (rand() < r) && (err01 == 0) && (err10 == 0)
        theta_new(:,ix1) = theta_new0;
        theta_new(:,ix0) = theta_new1;
        loglike_new(ix0) = l10; chainstats{1,ix0} = l10;
        loglike_new(ix1) = l01; chainstats{1,ix1} = l01;
        z_new(:,ix0) = z10; chainstats{2,ix0} = z10;
        z_new(:,ix1) = z01; chainstats{2,ix1} = z01;
        w_new(:,ix0) = w10; chainstats{3,ix0} = w10;
        w_new(:,ix1) = w01; chainstats{3,ix1} = w01;
        chainstats{4,ix0} = L10;
        chainstats{4,ix1} = L01;
        chainstats{5,ix0} = U10;
        chainstats{5,ix1} = U01;
        chainstats{6,ix0} = G10;
        chainstats{6,ix1} = G01;
        chainstats{7,ix0} = IG10;
        chainstats{7,ix1} = IG01;
        alpha = alpha + 1/length(ti);
    end
end

end

% observations must be indexed by row
function M = crosscovariance(X,Y)

n = size(X,1); % number of observations
px = size(X,2); % dimension of x
py = size(Y,2); % dimension of y

X = bsxfun(@minus,X,mean(X,1));
Y = bsxfun(@minus,Y,mean(Y,1));

M = 0;
for i = 1:n
    M = M + X(i,:)'*Y(i,:);
end
M = M/(n-1);


end

% Computes the thermodynamic integral
% Inputs:
% ti = temperature schedule
% theta = number of parameters x number of temperatures x N
% z = linear control variates, num params x num temperatures x N
% w = quadratic control variates, num params x num temperatures x N
% Outputs:
% [I_MC,I_ZV,I_CF] = row vector of estimated log-marginal likelihood
function [I_MC,I_ZV,I_CF] = thermodynamic_integral(ti,theta,loglike,z,w)

% load data
[d,T,N] = size(theta);
m = ceil(N/10); % remove the first 10% as burn-in
theta(:,:,1:m) = [];
loglike(1:m,:) = [];
z(:,:,1:m) = [];
w(:,:,1:m) = [];
N = N - m;

% classical Monte Carlo
Eloglike_std = mean(loglike,1); % E_theta|y,t log[p(y|theta)], integrand for I1
E2loglike_std = mean(loglike.^2,1);
Vloglike_std = E2loglike_std - (mean(loglike,1)).^2; % Friel correction

% the ZV approach of Mira et al., based on quadratic polynomials
Eloglike_QZV = zeros(1,T); % integrand for second order zero variance
a = estimate_coefficients(w,loglike); % quadratic coefficients
for i = 1:T
    for n = 1:N
        Eloglike_QZV(i) = Eloglike_QZV(i) + (loglike(n,i) + a(:,i)'*w(:,i,n)) / N;
    end
end
E2loglike_QZV = E2loglike_std; % Friel correction
a2 = estimate_coefficients(w, loglike.^2); % quadratic coefficients
for i = 1:T
    for n = 1:N
        E2loglike_QZV(i) = E2loglike_QZV(i) + a2(:,i)' * w(:,i,n) / N;
    end
end
Vloglike_QZV = E2loglike_QZV - Eloglike_QZV.^2;

% control functionals
Eloglike_prop = zeros(1,T); % first moment
E2loglike_prop = zeros(1,T); % second moment
Vloglike_prop = zeros(1,T); % variance
for i = 1:T
    x = squeeze(theta(:,i,:)); % samples
    f = loglike(:,i);
    f2 = f.^2;   
    u = -2 * squeeze(z(:,i,:));
    alpha = [0.1 , 3];
    cd('../')
    Eloglike_prop(i) = mean_CF(x,f,u,alpha,'simplified');
    E2loglike_prop(i) = mean_CF(x,f2,u,alpha,'simplified'); 
    cd('ODEs')
    Vloglike_prop(i) = E2loglike_prop(i) - Eloglike_prop(i)^2;
end

% Numerical integration
I_MC = 0; I_ZV = 0; I_CF = 0;
for i = 1:length(ti)-1 
    I_MC = I_MC + (Eloglike_std(i) + Eloglike_std(i+1))/2 * (ti(i+1)-ti(i)) - (Vloglike_std(i+1) - Vloglike_std(i))/12 * (ti(i+1)-ti(i))^2;
    % ZV of Mira et al. 
    I_ZV = I_ZV + (Eloglike_QZV(i) + Eloglike_QZV(i+1))/2 * (ti(i+1)-ti(i)) - (Vloglike_QZV(i+1) - Vloglike_QZV(i))/12 * (ti(i+1)-ti(i))^2;
    % control functionals
    I_CF = I_CF + (Eloglike_prop(i) + Eloglike_prop(i+1))/2 * (ti(i+1)-ti(i)) - (Vloglike_prop(i+1) - Vloglike_prop(i))/12 * (ti(i+1)-ti(i))^2;
end

end

% Estimate coefficients for control variants 
% Inputs:
% loglike = values of the loglikelihood, N x number of temperatures
% z = linear control variates, num params x num temperatures x N
% Outputs:
% a = d x T matrix of estimated coefficients
function a = estimate_coefficients(z,loglike)

[d,T,N] = size(z);

Ezz = zeros(d,d,T); % Ezz(:,:,t) is the sample covariance matrix for z(theta) at temperature t
for t = 1:T
    Ezz(:,:,t) = cov(squeeze(z(:,t,:))');
end

Egz = zeros(d,T); % Egz(:,t) is the sample cross-covariance matrix for g(theta) vs z(theta) at temperature t
for t = 1:T
    Egz(:,t) = crosscovariance(loglike(:,t),squeeze(z(:,t,:))');
end

a = zeros(d,T); % estimate the coefficients
for t = 1:T
    a(:,t) = - Ezz(:,:,t) \ Egz(:,t);
end

end

















